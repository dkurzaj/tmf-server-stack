////////////////////////////////////
//Plugin Auto TimeLimit
//Changes Timelimit for TimeAttack dynamically depending on the next
//  track's author time
//
//Written by ck|cyrus
//martin@die-webber.com
//www.chaoskrieger.com

////////////////
// Installation

- Copy file "plugin.autotime.php" into your XAseco plugin directory
- Copy file "autotime.xml" into your XAseco main directory
- Add <plugin>plugin.autotime.php</plugin> at the END of your "plugins.xml"
- Open file "autotime.xml" and edit the variables to your liking
- Have fun and enjoy playing with nice timings!

////////////////
// SUPPORT:

Visit: http://www.tm-forum.com/viewtopic.php?t=6563
ICQ: 85020221
